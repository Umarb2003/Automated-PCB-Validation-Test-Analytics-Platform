import math
import numpy as np


class VirtualBoard:
    """Software model of a simple power-management PCB."""

    def __init__(
        self,
        nominal_output_voltage=5.0,
        nominal_output_current=0.5,
        temperature=25.0,
        ripple=0.020
    ):
        self.nominal_output_voltage = nominal_output_voltage
        self.output_current = nominal_output_current
        self.temperature = temperature
        self.ripple = ripple

        self.input_voltage = 0.0
        self.powered = False

        self.faults = {
            "low_voltage": False,
            "high_current": False,
            "high_temperature": False,
            "high_ripple": False
        }

    def set_input_voltage(self, voltage):
        self.input_voltage = voltage

    def set_load_current(self, current):
        self.output_current = current

    def get_output_voltage(self):
        if not self.powered:
            return 0.0

        voltage = self.nominal_output_voltage

        # Simulate small output-voltage droop as load current increases.
        voltage -= self.output_current * 0.02

        if self.faults["low_voltage"]:
            voltage *= 0.82

        return voltage

    def get_output_current(self):
        if not self.powered:
            return 0.0

        current = self.output_current

        if self.faults["high_current"]:
            current *= 1.5

        return current

    def get_temperature(self):
        temperature = self.temperature + (self.output_current * 5)

        if self.faults["high_temperature"]:
            temperature += 45

        return temperature

    def get_ripple(self):
        ripple = self.ripple + (self.output_current * 0.005)

        if self.faults["high_ripple"]:
            ripple *= 6

        return ripple

    def generate_waveform(self, sample_rate=10000, duration=0.02):
        number_of_samples = int(sample_rate * duration)

        time_values = np.linspace(
            0,
            duration,
            number_of_samples,
            endpoint=False
        )

        dc_voltage = self.get_output_voltage()
        ripple = self.get_ripple()
        ripple_frequency = 1000

        waveform = (
            dc_voltage
            + (ripple / 2)
            * np.sin(2 * math.pi * ripple_frequency * time_values)
        )

        return time_values, waveform

    def inject_fault(self, fault_name):
        if fault_name not in self.faults:
            raise ValueError(f"Unknown fault: {fault_name}")

        self.faults[fault_name] = True

    def clear_fault(self, fault_name):
        if fault_name not in self.faults:
            raise ValueError(f"Unknown fault: {fault_name}")

        self.faults[fault_name] = False

    def clear_all_faults(self):
        for fault in self.faults:
            self.faults[fault] = False
