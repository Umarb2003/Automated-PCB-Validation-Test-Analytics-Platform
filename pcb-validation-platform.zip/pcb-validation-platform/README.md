# Automated PCB Validation & Test Analytics Platform

A software-based hardware validation environment developed in Python and C to model a simplified automated PCB test workflow.

The platform models a configurable device under test (DUT) and virtual laboratory instruments including a digital multimeter, programmable DC power supply, electronic load, and oscilloscope. Python test sequences automatically configure operating conditions, collect voltage, current, power, and ripple measurements, compare measurements against configurable engineering limits, and determine pass/fail status.

The DUT supports fault injection for undervoltage, overcurrent, excessive ripple, and high-temperature conditions, allowing the validation software to demonstrate failure detection rather than only successful test cases. Results are analyzed with Pandas and exported as CSV, JSON, and PDF engineering reports.

A separate C command-line waveform analyzer processes oscilloscope CSV data and calculates mean, RMS, minimum, maximum, and peak-to-peak voltage. This demonstrates integration between Python-based test automation and a Linux/command-line C measurement-processing utility.

This project is completely software-based and does not require external laboratory hardware.

## Technologies

- Python
- C
- NumPy
- Pandas
- ReportLab
- JSON
- Linux/GCC/Make
- Git

## Project Structure

```text
pcb-validation-platform/
├── main.py
├── requirements.txt
├── dut/
├── instruments/
├── tests/
├── analysis/
├── reporting/
├── config/
├── c_waveform_analyzer/
└── data/
```

## Setup

Create a Python virtual environment if desired, then install dependencies:

```bash
pip install -r requirements.txt
```

### Compile the C analyzer on Linux/WSL/macOS

```bash
cd c_waveform_analyzer
make
cd ..
```

On Windows with GCC/MinGW, an equivalent command is:

```bash
gcc c_waveform_analyzer/analyzer.c -o c_waveform_analyzer/analyzer.exe -lm
```

## Run

```bash
python main.py
```

Generated files are placed in `data/`:

- `results.csv`
- `report.json`
- `report.pdf`
- `waveform.csv`

## Fault Injection

In `main.py`, uncomment one of the fault lines after the `VirtualBoard` is created:

```python
board.inject_fault("low_voltage")
board.inject_fault("high_current")
board.inject_fault("high_temperature")
board.inject_fault("high_ripple")
```

Run the program again and observe which validation tests fail.

## Resume Summary

- Developed a Python-based automated PCB validation platform using simulated DMM, power supply, electronic load, and oscilloscope instruments to execute voltage, current, power, and ripple tests with configurable pass/fail limits.
- Implemented DUT fault injection and test analytics to detect undervoltage, overcurrent, excessive ripple, and thermal conditions, automatically exporting validation results to CSV, JSON, and PDF engineering reports.
- Built and integrated a C waveform analysis utility for RMS, mean, min/max, and peak-to-peak calculations on simulated oscilloscope data, connecting C measurement processing with the Python test automation workflow.
