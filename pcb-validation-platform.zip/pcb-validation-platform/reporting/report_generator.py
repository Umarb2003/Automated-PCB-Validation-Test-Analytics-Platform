import json

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas


def generate_json_report(results, summary, filename):
    report = {
        "summary": summary,
        "results": results
    }

    with open(filename, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=4)


def generate_pdf_report(results, summary, filename):
    pdf = canvas.Canvas(str(filename), pagesize=letter)
    _, height = letter
    y = height - 50

    pdf.setFont("Helvetica-Bold", 16)
    pdf.drawString(50, y, "PCB Validation Test Report")
    y -= 40

    pdf.setFont("Helvetica", 11)
    pdf.drawString(50, y, f"Total Tests: {summary['total_tests']}")
    y -= 20
    pdf.drawString(50, y, f"Passed: {summary['passed_tests']}")
    y -= 20
    pdf.drawString(50, y, f"Failed: {summary['failed_tests']}")
    y -= 20
    pdf.drawString(50, y, f"Pass Rate: {summary['pass_rate']:.1f}%")
    y -= 40

    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawString(50, y, "Test Results")
    y -= 25
    pdf.setFont("Helvetica", 10)

    for result in results:
        status = "PASS" if result["passed"] else "FAIL"

        line = (
            f"{result['test_name']}: "
            f"{result['measured']:.4f} "
            f"{result['unit']} - {status}"
        )

        pdf.drawString(50, y, line)
        y -= 20

    pdf.save()
