#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "analyzer.h"

#define MAX_SAMPLES 100000

double calculate_mean(double samples[], int count)
{
    double sum = 0.0;

    for (int i = 0; i < count; i++)
    {
        sum += samples[i];
    }

    return sum / count;
}

double calculate_rms(double samples[], int count)
{
    double sum_squared = 0.0;

    for (int i = 0; i < count; i++)
    {
        sum_squared += samples[i] * samples[i];
    }

    return sqrt(sum_squared / count);
}

double calculate_min(double samples[], int count)
{
    double minimum = samples[0];

    for (int i = 1; i < count; i++)
    {
        if (samples[i] < minimum)
        {
            minimum = samples[i];
        }
    }

    return minimum;
}

double calculate_max(double samples[], int count)
{
    double maximum = samples[0];

    for (int i = 1; i < count; i++)
    {
        if (samples[i] > maximum)
        {
            maximum = samples[i];
        }
    }

    return maximum;
}

double calculate_peak_to_peak(double samples[], int count)
{
    return calculate_max(samples, count) - calculate_min(samples, count);
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: %s waveform.csv\\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");

    if (file == NULL)
    {
        printf("Error: Could not open waveform file.\\n");
        return 1;
    }

    double samples[MAX_SAMPLES];
    int count = 0;
    double time;
    double voltage;
    char header[256];

    fgets(header, sizeof(header), file);

    while (
        fscanf(file, "%lf,%lf", &time, &voltage) == 2
        && count < MAX_SAMPLES
    )
    {
        samples[count] = voltage;
        count++;
    }

    fclose(file);

    if (count == 0)
    {
        printf("Error: No waveform samples found.\\n");
        return 1;
    }

    printf("Waveform Analysis\\n");
    printf("----------------------------\\n");
    printf("Samples:      %d\\n", count);
    printf("Mean:         %.6f V\\n", calculate_mean(samples, count));
    printf("RMS:          %.6f V\\n", calculate_rms(samples, count));
    printf("Minimum:      %.6f V\\n", calculate_min(samples, count));
    printf("Maximum:      %.6f V\\n", calculate_max(samples, count));
    printf("Peak-to-Peak: %.6f V\\n", calculate_peak_to_peak(samples, count));

    return 0;
}
