#ifndef ANALYZER_H
#define ANALYZER_H

double calculate_mean(double samples[], int count);
double calculate_rms(double samples[], int count);
double calculate_min(double samples[], int count);
double calculate_max(double samples[], int count);
double calculate_peak_to_peak(double samples[], int count);

#endif
