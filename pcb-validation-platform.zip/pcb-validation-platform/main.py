import json
import subprocess
from pathlib import Path

import pandas as pd

from dut.virtual_board import VirtualBoard
from instruments.dmm import DigitalMultimeter
from instruments.power_supply import PowerSupply
from instruments.electronic_load import ElectronicLoad
from instruments.oscilloscope import Oscilloscope

from tests.voltage_test import run_voltage_test
from tests.current_test import run_current_test
from tests.ripple_test import run_ripple_test
from tests.power_test import run_power_test

from analysis.analyzer import analyze_results, save_results_csv
from reporting.report_generator import generate_json_report, generate_pdf_report


PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIRECTORY = PROJECT_ROOT / "data"
DATA_DIRECTORY.mkdir(exist_ok=True)


def load_configuration():
    config_path = PROJECT_ROOT / "config" / "test_config.json"

    with open(config_path, "r", encoding="utf-8") as file:
        return json.load(file)


def save_waveform(time_values, waveform):
    dataframe = pd.DataFrame({
        "time": time_values,
        "voltage": waveform
    })

    waveform_path = DATA_DIRECTORY / "waveform.csv"
    dataframe.to_csv(waveform_path, index=False)

    return waveform_path


def run_c_analyzer(waveform_path):
    analyzer_directory = PROJECT_ROOT / "c_waveform_analyzer"

    # Linux/macOS build name.
    analyzer_path = analyzer_directory / "analyzer"

    # Windows users may compile to analyzer.exe.
    if not analyzer_path.exists():
        windows_path = analyzer_directory / "analyzer.exe"

        if windows_path.exists():
            analyzer_path = windows_path
        else:
            print(
                "\nC analyzer not compiled. "
                "Compile analyzer.c first; Python tests still completed."
            )
            return

    result = subprocess.run(
        [str(analyzer_path), str(waveform_path)],
        capture_output=True,
        text=True,
        check=False
    )

    print("\nC WAVEFORM ANALYZER")
    print("-" * 50)

    if result.stdout:
        print(result.stdout)

    if result.stderr:
        print(result.stderr)


def main():
    print("=" * 50)
    print("AUTOMATED PCB VALIDATION PLATFORM")
    print("=" * 50)

    config = load_configuration()

    board = VirtualBoard()

    # Uncomment one of these to demonstrate fault detection:
    # board.inject_fault("low_voltage")
    # board.inject_fault("high_current")
    # board.inject_fault("high_temperature")
    # board.inject_fault("high_ripple")

    power_supply = PowerSupply(board)
    electronic_load = ElectronicLoad(board)
    dmm = DigitalMultimeter(board)
    oscilloscope = Oscilloscope(board)

    power_supply.set_voltage(
        config["power_supply"]["input_voltage"]
    )

    power_supply.set_current_limit(
        config["power_supply"]["current_limit"]
    )

    power_supply.output_on()

    electronic_load.set_current(
        config["load"]["current"]
    )

    electronic_load.enable()

    limits = config["limits"]
    results = []

    results.append(
        run_voltage_test(
            dmm,
            limits["output_voltage"]["minimum"],
            limits["output_voltage"]["maximum"]
        )
    )

    results.append(
        run_current_test(
            dmm,
            electronic_load,
            config["load"]["current"],
            limits["output_current"]["minimum"],
            limits["output_current"]["maximum"]
        )
    )

    results.append(
        run_ripple_test(
            oscilloscope,
            limits["output_ripple"]["maximum"]
        )
    )

    results.append(
        run_power_test(
            dmm,
            limits["output_power"]["maximum"]
        )
    )

    print("\nTEST RESULTS")
    print("-" * 50)

    for result in results:
        status = "PASS" if result["passed"] else "FAIL"

        print(
            f"{result['test_name']:<20}"
            f"{result['measured']:.4f} "
            f"{result['unit']:<5} "
            f"{status}"
        )

    summary = analyze_results(results)

    print("\nSUMMARY")
    print("-" * 50)
    print(f"Total Tests: {summary['total_tests']}")
    print(f"Passed:      {summary['passed_tests']}")
    print(f"Failed:      {summary['failed_tests']}")
    print(f"Pass Rate:   {summary['pass_rate']:.1f}%")

    save_results_csv(
        results,
        DATA_DIRECTORY / "results.csv"
    )

    generate_json_report(
        results,
        summary,
        DATA_DIRECTORY / "report.json"
    )

    generate_pdf_report(
        results,
        summary,
        DATA_DIRECTORY / "report.pdf"
    )

    time_values, waveform = oscilloscope.capture_waveform()
    waveform_path = save_waveform(time_values, waveform)
    run_c_analyzer(waveform_path)

    electronic_load.disable()
    power_supply.output_off()

    print("\nReports saved in:", DATA_DIRECTORY)


if __name__ == "__main__":
    main()
