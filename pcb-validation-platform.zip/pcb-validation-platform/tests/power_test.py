def run_power_test(dmm, maximum):
    voltage = dmm.measure_voltage()
    current = dmm.measure_current()

    power = voltage * current
    passed = power <= maximum

    return {
        "test_name": "Output Power",
        "measured": power,
        "minimum": 0.0,
        "maximum": maximum,
        "unit": "W",
        "passed": passed
    }
