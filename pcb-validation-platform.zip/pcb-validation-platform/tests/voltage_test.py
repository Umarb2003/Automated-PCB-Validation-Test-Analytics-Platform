def run_voltage_test(dmm, minimum, maximum):
    measured_voltage = dmm.measure_voltage()
    passed = minimum <= measured_voltage <= maximum

    return {
        "test_name": "Output Voltage",
        "measured": measured_voltage,
        "minimum": minimum,
        "maximum": maximum,
        "unit": "V",
        "passed": passed
    }
