def run_ripple_test(oscilloscope, maximum):
    _, waveform = oscilloscope.capture_waveform()
    measured_ripple = oscilloscope.measure_peak_to_peak(waveform)
    passed = measured_ripple <= maximum

    return {
        "test_name": "Output Ripple",
        "measured": measured_ripple,
        "minimum": 0.0,
        "maximum": maximum,
        "unit": "Vpp",
        "passed": passed
    }
