def run_current_test(dmm, electronic_load, load_current, minimum, maximum):
    electronic_load.set_current(load_current)
    electronic_load.enable()

    measured_current = dmm.measure_current()
    passed = minimum <= measured_current <= maximum

    return {
        "test_name": "Output Current",
        "measured": measured_current,
        "minimum": minimum,
        "maximum": maximum,
        "unit": "A",
        "passed": passed
    }
