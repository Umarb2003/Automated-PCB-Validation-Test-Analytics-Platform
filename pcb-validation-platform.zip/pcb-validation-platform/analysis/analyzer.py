import pandas as pd


def analyze_results(results):
    dataframe = pd.DataFrame(results)

    total_tests = len(dataframe)
    passed_tests = int(dataframe["passed"].sum()) if total_tests else 0
    failed_tests = total_tests - passed_tests
    pass_rate = (passed_tests / total_tests) * 100 if total_tests else 0.0

    failed_test_names = (
        dataframe.loc[dataframe["passed"] == False, "test_name"].tolist()
        if total_tests else []
    )

    return {
        "total_tests": total_tests,
        "passed_tests": passed_tests,
        "failed_tests": failed_tests,
        "pass_rate": pass_rate,
        "failed_test_names": failed_test_names
    }


def save_results_csv(results, filename):
    dataframe = pd.DataFrame(results)
    dataframe.to_csv(filename, index=False)
