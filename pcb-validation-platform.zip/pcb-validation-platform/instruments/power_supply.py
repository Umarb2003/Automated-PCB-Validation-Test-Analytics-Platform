class PowerSupply:
    """Simulated programmable DC power supply."""

    def __init__(self, board):
        self.board = board
        self.voltage = 0.0
        self.current_limit = 1.0
        self.output_enabled = False

    def set_voltage(self, voltage):
        if voltage < 0:
            raise ValueError("Voltage cannot be negative.")

        self.voltage = voltage

        if self.output_enabled:
            self.board.set_input_voltage(voltage)

    def set_current_limit(self, current):
        if current <= 0:
            raise ValueError("Current limit must be greater than zero.")

        self.current_limit = current

    def output_on(self):
        self.output_enabled = True
        self.board.powered = True
        self.board.set_input_voltage(self.voltage)

    def output_off(self):
        self.output_enabled = False
        self.board.powered = False
        self.board.set_input_voltage(0.0)

    def get_voltage(self):
        return self.voltage

    def get_current_limit(self):
        return self.current_limit
