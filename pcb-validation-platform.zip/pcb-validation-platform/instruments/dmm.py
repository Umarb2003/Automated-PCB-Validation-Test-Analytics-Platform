import random


class DigitalMultimeter:
    """Simulated DMM with small Gaussian measurement uncertainty."""

    def __init__(self, board):
        self.board = board

    def measure_voltage(self):
        actual_voltage = self.board.get_output_voltage()
        noise = random.gauss(0, 0.005)
        return actual_voltage + noise

    def measure_current(self):
        actual_current = self.board.get_output_current()
        noise = random.gauss(0, 0.002)
        return actual_current + noise
