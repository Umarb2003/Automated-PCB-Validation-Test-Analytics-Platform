class ElectronicLoad:
    """Simulated programmable electronic load."""

    def __init__(self, board):
        self.board = board
        self.current = 0.0
        self.enabled = False

    def set_current(self, current):
        if current < 0:
            raise ValueError("Load current cannot be negative.")

        self.current = current

        if self.enabled:
            self.board.set_load_current(current)

    def enable(self):
        self.enabled = True
        self.board.set_load_current(self.current)

    def disable(self):
        self.enabled = False
        self.board.set_load_current(0.0)

    def get_current(self):
        return self.current
