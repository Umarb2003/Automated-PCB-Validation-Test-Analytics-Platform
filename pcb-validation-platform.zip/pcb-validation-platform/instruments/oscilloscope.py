import numpy as np


class Oscilloscope:
    """Simulated oscilloscope for waveform acquisition and measurements."""

    def __init__(self, board):
        self.board = board

    def capture_waveform(self, sample_rate=10000, duration=0.02):
        time_values, waveform = self.board.generate_waveform(
            sample_rate,
            duration
        )

        measurement_noise = np.random.normal(
            0,
            0.002,
            len(waveform)
        )

        measured_waveform = waveform + measurement_noise

        return time_values, measured_waveform

    def measure_peak_to_peak(self, waveform):
        return float(np.max(waveform) - np.min(waveform))

    def measure_rms(self, waveform):
        return float(np.sqrt(np.mean(np.square(waveform))))
